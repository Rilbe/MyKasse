Bike Rental CRM — Ready for Vercel

How to use (locally):
1. npm install
2. npm start

For Vercel:
- Create a Git repo, push, then connect to Vercel or run `vercel` in the folder.

Notes:
- Tailwind is configured via PostCSS.
- This project uses localStorage for data (no backend).
